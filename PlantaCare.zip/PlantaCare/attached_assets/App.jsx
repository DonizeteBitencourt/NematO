import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, CameraIcon, History, Leaf, User } from "lucide-react";
import { motion } from "framer-motion";

export default function PlantDiagnosisApp() {
  const [image, setImage] = useState(null);
  const [diagnosis, setDiagnosis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          setLocation({ latitude, longitude });
        },
        (err) => console.error("Erro ao obter localização:", err)
      );
    }
  }, []);

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    setImage(URL.createObjectURL(file));
    setLoading(true);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("http://localhost:8000/diagnose", {
        method: "POST",
        body: formData
      });

      const data = await res.json();
      setDiagnosis(data.diagnosis);

      const entry = {
        date: new Date().toLocaleString(),
        image: URL.createObjectURL(file),
        location,
        results: data.diagnosis
      };
      setHistory((prev) => [entry, ...prev]);
    } catch (err) {
      console.error("Erro ao diagnosticar:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-6">
      <nav className="flex justify-around p-4 shadow rounded-2xl bg-white">
        <Button variant="ghost"><CameraIcon className="mr-2" /> Diagnóstico</Button>
        <Button variant="ghost"><History className="mr-2" /> Histórico</Button>
        <Button variant="ghost"><MapPin className="mr-2" /> Mapa</Button>
        <Button variant="ghost"><User className="mr-2" /> Propriedade</Button>
      </nav>

      <Card className="bg-green-50">
        <CardContent className="p-6 space-y-4">
          <h2 className="text-xl font-bold flex items-center"><Leaf className="mr-2" /> Enviar Foto da Planta</h2>
          <Input type="file" accept="image/*" onChange={handleImageUpload} />
          {image && <img src={image} alt="Planta" className="max-w-xs rounded shadow" />}

          {loading && <p className="text-sm text-gray-500">Analisando imagem com IA...</p>}

          {diagnosis && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
              <h3 className="text-lg font-semibold text-green-800">Diagnóstico</h3>
              {diagnosis.map((item, idx) => (
                <p key={idx}><strong>{item.label}:</strong> {item.score}%</p>
              ))}
              {location && (
                <p className="text-sm text-gray-500">Localização: {location.latitude.toFixed(5)}, {location.longitude.toFixed(5)}</p>
              )}
            </motion.div>
          )}
        </CardContent>
      </Card>

      {history.length > 0 && (
        <Card>
          <CardContent className="p-6 space-y-4">
            <h2 className="text-lg font-bold flex items-center"><History className="mr-2" /> Histórico de Diagnósticos</h2>
            {history.map((entry, idx) => (
              <div key={idx} className="border p-2 rounded">
                <p className="text-sm">{entry.date}</p>
                {entry.location && (
                  <p className="text-xs text-gray-500">Local: {entry.location.latitude.toFixed(5)}, {entry.location.longitude.toFixed(5)}</p>
                )}
                <img src={entry.image} alt="Histórico" className="max-w-xs rounded shadow my-2" />
                {entry.results.map((res, i) => (
                  <p key={i}><strong>{res.label}:</strong> {res.score}%</p>
                ))}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}