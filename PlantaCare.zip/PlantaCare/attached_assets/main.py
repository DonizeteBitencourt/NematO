from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import random

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class DiagnosisResult(BaseModel):
    label: str
    score: float

class DiagnosisResponse(BaseModel):
    diagnosis: List[DiagnosisResult]

@app.post("/diagnose", response_model=DiagnosisResponse)
async def diagnose(file: UploadFile = File(...)):
    # Simula IA com resultados fictícios
    classes = ["Ferrugem Asiática - Phakopsora pachyrhizi", "Antracnose", "Míldio", "Sadio"]
    results = [
        {"label": cls, "score": round(random.uniform(70, 99), 2)}
        for cls in random.sample(classes, k=2)
    ]
    return {"diagnosis": results}