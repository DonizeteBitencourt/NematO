let currentLocation = null;

function initGeolocation() {
    // Try to get the user's location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            // Success callback
            position => {
                const { latitude, longitude } = position.coords;
                currentLocation = { latitude, longitude };
                updateLocationDisplay();
            },
            // Error callback
            error => {
                console.error("Erro ao obter localização:", error);
                document.getElementById('location-coordinates').textContent = 
                    "Localização não disponível. Verifique as permissões do navegador.";
            },
            // Options
            {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            }
        );
    } else {
        document.getElementById('location-coordinates').textContent = 
            "Geolocalização não suportada pelo navegador.";
    }
}

function updateLocationDisplay() {
    const locationElement = document.getElementById('location-coordinates');
    
    if (currentLocation && locationElement) {
        locationElement.textContent = `Latitude: ${currentLocation.latitude.toFixed(5)}, Longitude: ${currentLocation.longitude.toFixed(5)}`;
    }
}

function getFormattedLocation() {
    if (!currentLocation) return "Localização não disponível";
    
    return `Latitude: ${currentLocation.latitude.toFixed(5)}, Longitude: ${currentLocation.longitude.toFixed(5)}`;
}
