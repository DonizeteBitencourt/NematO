// Property management functionality
function initProperty() {
    // Get the property form element
    const propertyForm = document.getElementById('property-form');
    const successMessage = document.getElementById('property-success-message');
    
    // Check if we already have property data
    loadPropertyData();
    
    // Handle form submission
    if (propertyForm) {
        propertyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Collect form data
            const propertyData = {
                name: document.getElementById('property-name').value,
                owner: document.getElementById('property-owner').value,
                area: document.getElementById('property-area').value,
                state: document.getElementById('property-state').value,
                city: document.getElementById('property-city').value,
                address: document.getElementById('property-address').value,
                main_crop: document.getElementById('property-main-crop').value,
                planted_area: document.getElementById('property-planted-area').value,
                notes: document.getElementById('property-notes').value || ''
            };
            
            // Submit data to the server
            fetch('/property', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(propertyData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message
                    successMessage.classList.remove('d-none');
                    
                    // Hide success message after 3 seconds
                    setTimeout(() => {
                        successMessage.classList.add('d-none');
                    }, 3000);
                } else {
                    alert('Erro ao salvar propriedade: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ocorreu um erro ao salvar os dados da propriedade.');
            });
        });
    }
}

function loadPropertyData() {
    // Fetch property data from server
    fetch('/property')
        .then(response => {
            if (!response.ok) {
                if (response.status === 404) {
                    // No property data yet, that's fine
                    return null;
                }
                throw new Error('Error fetching property data');
            }
            return response.json();
        })
        .then(data => {
            if (data && data.success && data.property) {
                // Fill form with existing property data
                fillPropertyForm(data.property);
            }
        })
        .catch(error => {
            // Just log the error but don't show alert to user
            // It's normal not to have property data initially
            console.log('No property data available yet:', error);
        });
}

function fillPropertyForm(propertyData) {
    // Fill each form field with data from the server
    document.getElementById('property-name').value = propertyData.name || '';
    document.getElementById('property-owner').value = propertyData.owner || '';
    document.getElementById('property-area').value = propertyData.area || '';
    document.getElementById('property-state').value = propertyData.state || '';
    document.getElementById('property-city').value = propertyData.city || '';
    document.getElementById('property-address').value = propertyData.address || '';
    document.getElementById('property-main-crop').value = propertyData.main_crop || '';
    document.getElementById('property-planted-area').value = propertyData.planted_area || '';
    document.getElementById('property-notes').value = propertyData.notes || '';
}