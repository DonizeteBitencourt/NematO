function loadHistory() {
    // Get history from localStorage
    const history = getHistoryFromStorage();
    
    // Update UI based on history
    updateHistoryUI(history);
}

function getHistoryFromStorage() {
    const historyJSON = localStorage.getItem('nomatoDiagnosisHistory');
    // Verificar se existe histórico no nome antigo e migrar
    if (!historyJSON) {
        const oldHistoryJSON = localStorage.getItem('plantDiagnosisHistory');
        if (oldHistoryJSON) {
            localStorage.setItem('nomatoDiagnosisHistory', oldHistoryJSON);
            return JSON.parse(oldHistoryJSON);
        }
    }
    return historyJSON ? JSON.parse(historyJSON) : [];
}

function saveToHistory(file, diagnosisData) {
    // Create a history entry
    const reader = new FileReader();
    reader.onload = function(e) {
        const historyEntry = {
            id: Date.now(),
            date: new Date().toISOString(),
            imageData: e.target.result,
            location: currentLocation,
            results: diagnosisData.diagnosis,
            treatment: {
                status: 'Não iniciado',
                notes: '',
                lastUpdated: new Date().toISOString()
            }
        };
        
        // Get existing history
        const history = getHistoryFromStorage();
        
        // Add new entry at the beginning
        history.unshift(historyEntry);
        
        // Limit history to 20 items to avoid localStorage size issues
        const limitedHistory = history.slice(0, 20);
        
        // Save back to localStorage
        localStorage.setItem('nomatoDiagnosisHistory', JSON.stringify(limitedHistory));
        
        // Update history UI
        updateHistoryUI(limitedHistory);
        
        // Update map if location is available
        if (currentLocation) {
            // Add location to map
            addLocationToMap(diagnosisData.diagnosis, currentLocation);
            
            // Update map markers
            setTimeout(updateMapMarkers, 500);
            
            // Add mini map to diagnosis result if not already added
            setTimeout(updateLocationMapPreview, 500);
        }
    };
    
    reader.readAsDataURL(file);
}

function updateHistoryUI(history) {
    const historyContainer = document.getElementById('history-container');
    const noHistory = document.getElementById('no-history');
    const historyList = document.getElementById('history-list');
    
    // Clear current history display
    historyList.innerHTML = '';
    
    if (history.length === 0) {
        // Show "no history" message
        noHistory.classList.remove('d-none');
        return;
    }
    
    // Hide "no history" message
    noHistory.classList.add('d-none');
    
    // Create history items
    history.forEach(entry => {
        const historyItem = document.createElement('div');
        historyItem.className = 'history-item mb-4 border rounded p-3';
        historyItem.setAttribute('data-id', entry.id);
        historyItem.style.cursor = 'pointer';
        
        let locationText = 'Localização não disponível';
        if (entry.location) {
            locationText = `Latitude: ${entry.location.latitude.toFixed(5)}, Longitude: ${entry.location.longitude.toFixed(5)}`;
        }
        
        // Create results HTML
        let resultsHtml = '';
        entry.results.forEach(item => {
            // Determine color based on score (higher score is more concerning unless it's "Sadio")
            let badgeClass = 'bg-success';
            if (item.label !== "Sadio" && item.score > 85) {
                badgeClass = 'bg-danger';
            } else if (item.label !== "Sadio" && item.score > 70) {
                badgeClass = 'bg-warning';
            }
            
            resultsHtml += `
                <div class="mb-2">
                    <span class="badge ${badgeClass}">${item.score}%</span>
                    <span>${item.label}</span>
                </div>
            `;
        });
        
        // Set up treatment status badge
        let treatmentStatusClass = 'bg-secondary';
        if (entry.treatment) {
            if (entry.treatment.status === 'Em tratamento') {
                treatmentStatusClass = 'bg-warning';
            } else if (entry.treatment.status === 'Concluído') {
                treatmentStatusClass = 'bg-success';
            } else if (entry.treatment.status === 'Não tratável') {
                treatmentStatusClass = 'bg-danger';
            }
        }
        
        const treatmentStatus = entry.treatment ? entry.treatment.status : 'Não iniciado';
        
        historyItem.innerHTML = `
            <div class="row">
                <div class="col-md-4">
                    <img src="${entry.imageData}" alt="Planta diagnosticada" class="img-fluid rounded history-image">
                </div>
                <div class="col-md-8">
                    <div class="d-flex justify-content-between">
                        <p class="history-date mb-1">
                            <i class="fas fa-calendar-alt me-1"></i> ${formatDate(entry.date)}
                        </p>
                        <button class="btn btn-sm btn-outline-danger delete-history" data-id="${entry.id}">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                    <div class="d-flex flex-wrap gap-2 align-items-center mb-2">
                        <span class="badge ${treatmentStatusClass}">${treatmentStatus}</span>
                        <span class="small text-secondary">
                            Atualizado: ${formatDate(entry.treatment ? entry.treatment.lastUpdated : entry.date)}
                        </span>
                    </div>
                    <p class="history-location mb-2">
                        <i class="fas fa-map-marker-alt me-1"></i> ${locationText}
                    </p>
                    <h5 class="mt-2">Diagnóstico:</h5>
                    <div class="diagnosis-results">
                        ${resultsHtml}
                    </div>
                    <button class="btn btn-sm btn-outline-primary mt-2 view-details-btn">
                        <i class="fas fa-search me-1"></i> Ver detalhes
                    </button>
                </div>
            </div>
            <div class="history-details mt-3 d-none">
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <h5>Tratamento</h5>
                        <div class="form-group mb-3">
                            <label for="treatment-status-${entry.id}" class="form-label">Status do tratamento:</label>
                            <select class="form-select treatment-status" id="treatment-status-${entry.id}" data-id="${entry.id}">
                                <option value="Não iniciado" ${treatmentStatus === 'Não iniciado' ? 'selected' : ''}>Não iniciado</option>
                                <option value="Em tratamento" ${treatmentStatus === 'Em tratamento' ? 'selected' : ''}>Em tratamento</option>
                                <option value="Concluído" ${treatmentStatus === 'Concluído' ? 'selected' : ''}>Concluído</option>
                                <option value="Não tratável" ${treatmentStatus === 'Não tratável' ? 'selected' : ''}>Não tratável</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="treatment-notes-${entry.id}" class="form-label">Anotações:</label>
                            <textarea class="form-control treatment-notes" id="treatment-notes-${entry.id}" 
                                rows="3" data-id="${entry.id}">${entry.treatment ? entry.treatment.notes : ''}</textarea>
                        </div>
                        <button class="btn btn-success mt-2 save-treatment-btn" data-id="${entry.id}">
                            <i class="fas fa-save me-1"></i> Salvar alterações
                        </button>
                    </div>
                    <div class="col-md-6">
                        <h5>Localização</h5>
                        ${entry.location ? 
                            `<div class="mini-map" id="mini-map-${entry.id}" style="height: 200px; border-radius: 0.25rem;"></div>` : 
                            `<div class="alert alert-secondary">Localização não disponível para este diagnóstico.</div>`
                        }
                    </div>
                </div>
            </div>
        `;
        
        historyList.appendChild(historyItem);
        
        // Add click handler to view details
        historyItem.querySelector('.view-details-btn').addEventListener('click', function(e) {
            e.stopPropagation();
            const detailsSection = historyItem.querySelector('.history-details');
            detailsSection.classList.toggle('d-none');
            
            // Initialize mini map if location exists and details are visible
            if (entry.location && !detailsSection.classList.contains('d-none')) {
                setTimeout(() => {
                    initMiniMap(`mini-map-${entry.id}`, entry.location, entry.results);
                }, 100);
            }
        });
        
        // Add delete functionality
        historyItem.querySelector('.delete-history').addEventListener('click', function(e) {
            e.stopPropagation();
            deleteHistoryItem(entry.id);
        });
        
        // Add save treatment functionality
        const saveTreatmentBtn = historyItem.querySelector('.save-treatment-btn');
        if (saveTreatmentBtn) {
            saveTreatmentBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                const id = this.getAttribute('data-id');
                const status = document.getElementById(`treatment-status-${id}`).value;
                const notes = document.getElementById(`treatment-notes-${id}`).value;
                updateTreatmentInfo(id, status, notes);
            });
        }
    });
}

function initMiniMap(containerId, location, results) {
    // Create mini map for the location
    const miniMap = L.map(containerId, {
        zoomControl: false,
        attributionControl: false
    }).setView([location.latitude, location.longitude], 13);
    
    // Add tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
    }).addTo(miniMap);
    
    // Add marker with severity color based on diagnosis
    let severity = 'low';
    results.forEach(result => {
        if (result.label !== 'Sadio' && result.score > 85) {
            severity = 'high';
        } else if (result.label !== 'Sadio' && result.score > 70 && severity !== 'high') {
            severity = 'medium';
        }
    });
    
    let markerColor = '#28a745'; // Default green
    if (severity === 'high') {
        markerColor = '#dc3545'; // Red
    } else if (severity === 'medium') {
        markerColor = '#ffc107'; // Yellow
    }
    
    // Add marker
    L.circleMarker([location.latitude, location.longitude], {
        radius: 8,
        fillColor: markerColor,
        color: '#fff',
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
    }).addTo(miniMap);
    
    // Disable dragging and zooming for mini map
    miniMap.dragging.disable();
    miniMap.touchZoom.disable();
    miniMap.doubleClickZoom.disable();
    miniMap.scrollWheelZoom.disable();
    
    // Fix Leaflet display issue by refreshing the map after it's displayed
    setTimeout(() => {
        miniMap.invalidateSize();
    }, 100);
}

function updateTreatmentInfo(id, status, notes) {
    // Get history
    const history = getHistoryFromStorage();
    
    // Find the entry
    const entryIndex = history.findIndex(item => item.id == id);
    
    if (entryIndex !== -1) {
        // Update the entry's treatment info
        history[entryIndex].treatment = {
            status: status,
            notes: notes,
            lastUpdated: new Date().toISOString()
        };
        
        // Save back to localStorage
        localStorage.setItem('nomatoDiagnosisHistory', JSON.stringify(history));
        
        // Update the UI
        updateHistoryUI(history);
        
        // Show confirmation toast
        showToast('Informações de tratamento atualizadas com sucesso!', 'success');
    }
}

function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.id = toastId;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add to container
    toastContainer.appendChild(toast);
    
    // Initialize and show the toast
    const bsToast = new bootstrap.Toast(toast, {
        animation: true,
        autohide: true,
        delay: 3000
    });
    bsToast.show();
    
    // Remove from DOM after hiding
    toast.addEventListener('hidden.bs.toast', function() {
        this.remove();
    });
}

function deleteHistoryItem(id) {
    // Get current history
    const history = getHistoryFromStorage();
    
    // Remove the item with the matching id
    const updatedHistory = history.filter(item => item.id !== id);
    
    // Save back to localStorage
    localStorage.setItem('nomatoDiagnosisHistory', JSON.stringify(updatedHistory));
    
    // Update UI
    updateHistoryUI(updatedHistory);
}
