document.addEventListener('DOMContentLoaded', () => {
    // Initialize the application
    initApp();
});

function initApp() {
    // Start with the diagnosis tab active
    showTab('diagnosis');
    
    // Initialize other components
    initGeolocation();
    initDiagnosis();
    loadHistory();
    initProperty();
    initMap();
}

function showTab(tabName) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => {
        tab.classList.add('d-none');
    });
    
    // Show the selected tab content
    const selectedTab = document.getElementById(`${tabName}-tab`);
    if (selectedTab) {
        selectedTab.classList.remove('d-none');
    }
    
    // Update active nav item
    const navItems = document.querySelectorAll('.nav-item-custom');
    navItems.forEach(item => {
        item.classList.remove('active');
    });
    
    const activeNav = document.getElementById(`nav-${tabName}`);
    if (activeNav) {
        activeNav.classList.add('active');
    }
}

// Helper function to format date
function formatDate(date) {
    return new Date(date).toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Helper function to get disease recommendations
function getDiseaseRecommendations(diseaseName) {
    const recommendations = {
        "Ferrugem Asiática - Phakopsora pachyrhizi": [
            "Utilize fungicidas preventivos no início da floração",
            "Faça rotação de culturas para reduzir o inóculo",
            "Monitore a lavoura regularmente, especialmente em períodos úmidos"
        ],
        "Antracnose": [
            "Aplique fungicidas registrados para a cultura",
            "Evite irrigação por aspersão em períodos críticos",
            "Use sementes sadias e certificadas"
        ],
        "Míldio": [
            "Reduza a umidade no ambiente com espaçamento adequado",
            "Aplique fungicidas preventivos em condições favoráveis à doença",
            "Evite o plantio em áreas com histórico da doença"
        ],
        "Sadio": [
            "Continue o monitoramento regular da lavoura",
            "Mantenha práticas adequadas de manejo e nutrição",
            "Realize amostragens periódicas para verificação"
        ],
        "Mancha Alvo": [
            "Utilize fungicidas específicos para o controle",
            "Adote rotação de culturas",
            "Monitore a incidência em períodos chuvosos"
        ],
        "Mancha Parda": [
            "Trate as sementes antes do plantio",
            "Use variedades resistentes quando disponíveis",
            "Aplique fungicidas no momento correto"
        ],
        "Oídio": [
            "Aplique fungicidas ao primeiro sinal da doença",
            "Evite excesso de adubação nitrogenada",
            "Monitore as condições de baixa umidade e temperaturas amenas"
        ],
        "Mofo Branco": [
            "Reduza a densidade de plantio para aumentar ventilação",
            "Faça rotação com gramíneas por pelo menos 3 anos",
            "Aplique fungicidas específicos nos estádios reprodutivos"
        ]
    };
    
    return recommendations[diseaseName] || [
        "Consulte um agrônomo para diagnóstico preciso",
        "Monitore a evolução dos sintomas",
        "Isole plantas afetadas para evitar disseminação"
    ];
}
