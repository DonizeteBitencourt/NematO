function initDiagnosis() {
    // Get form and attach submit event
    const uploadForm = document.getElementById('upload-form');
    const fileInput = document.getElementById('plant-image');
    const imagePreview = document.getElementById('image-preview');
    const previewContainer = document.querySelector('.image-preview-container');
    
    // Set up image preview
    fileInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                previewContainer.classList.remove('d-none');
            }
            reader.readAsDataURL(file);
        } else {
            previewContainer.classList.add('d-none');
        }
    });
    
    // Handle form submission
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const file = fileInput.files[0];
        if (!file) {
            alert('Por favor, selecione uma imagem para análise.');
            return;
        }
        
        // Show loading indicator
        const loadingIndicator = document.getElementById('loading-indicator');
        loadingIndicator.classList.remove('d-none');
        
        // Hide previous results if any
        const diagnosisResult = document.getElementById('diagnosis-result');
        diagnosisResult.classList.add('d-none');
        
        // Create form data
        const formData = new FormData();
        formData.append('file', file);
        
        // Send request to the backend
        fetch('/diagnose', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na solicitação: ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            // Process and display results
            displayDiagnosisResults(data);
            
            // Save to history
            saveToHistory(file, data);
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Ocorreu um erro ao processar a imagem. Por favor, tente novamente.');
        })
        .finally(() => {
            // Hide loading indicator
            loadingIndicator.classList.add('d-none');
        });
    });
}

function displayDiagnosisResults(data) {
    const resultContainer = document.getElementById('result-container');
    const diagnosisResult = document.getElementById('diagnosis-result');
    const recommendationsContainer = document.getElementById('recommendations');
    
    // Clear previous results
    resultContainer.innerHTML = '';
    recommendationsContainer.innerHTML = '';
    
    if (data.diagnosis && data.diagnosis.length > 0) {
        // Create results HTML
        data.diagnosis.forEach(item => {
            const resultItem = document.createElement('div');
            resultItem.className = 'diagnosis-result-item';
            
            // Determine color based on score (higher score is more concerning unless it's "Sadio")
            let progressClass = 'bg-success';
            if (item.label !== "Sadio" && item.score > 85) {
                progressClass = 'bg-danger';
            } else if (item.label !== "Sadio" && item.score > 70) {
                progressClass = 'bg-warning';
            }
            
            resultItem.innerHTML = `
                <h5>${item.label}</h5>
                <div class="progress mb-2">
                    <div class="progress-bar ${progressClass}" role="progressbar" 
                         style="width: ${item.score}%" aria-valuenow="${item.score}" 
                         aria-valuemin="0" aria-valuemax="100">
                        ${item.score}%
                    </div>
                </div>
            `;
            
            resultContainer.appendChild(resultItem);
        });
        
        // Add recommendations for the top result
        const topDisease = data.diagnosis[0].label;
        const recommendations = getDiseaseRecommendations(topDisease);
        
        const recommendationsList = document.createElement('ul');
        recommendations.forEach(rec => {
            const li = document.createElement('li');
            li.textContent = rec;
            recommendationsList.appendChild(li);
        });
        
        recommendationsContainer.appendChild(recommendationsList);
        
        // Show results
        diagnosisResult.classList.remove('d-none');
        
        // Update location if available
        updateLocationDisplay();
    } else {
        resultContainer.innerHTML = '<p class="alert alert-warning">Não foi possível determinar um diagnóstico para esta imagem.</p>';
        diagnosisResult.classList.remove('d-none');
    }
}
