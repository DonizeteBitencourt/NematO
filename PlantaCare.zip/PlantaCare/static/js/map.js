// Global map variables
let mainMap;
let markers = [];

function initMap() {
    // Check if map container exists
    const mapContainer = document.getElementById('map-container');
    if (!mapContainer) return;
    
    // Initialize the map centered on Brazil
    mainMap = L.map('map-container').setView([-15.77972, -47.92972], 4);
    
    // Add tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(mainMap);
    
    // Fix Leaflet display issue by refreshing the map after it's displayed
    document.querySelectorAll('.nav-link-custom').forEach(tab => {
        tab.addEventListener('click', function() {
            if (this.getAttribute('data-tab') === 'map') {
                setTimeout(() => {
                    mainMap.invalidateSize();
                    // Load markers if any exist
                    loadMapMarkers();
                }, 100);
            }
        });
    });
    
    // Add scale control
    L.control.scale({
        imperial: false,
        metric: true
    }).addTo(mainMap);
    
    // Initial load of markers
    loadMapMarkers();
}

function loadMapMarkers() {
    // Clear existing markers
    clearMarkers();
    
    // Get history entries with location data
    const history = getHistoryFromStorage();
    const entriesWithLocation = history.filter(entry => entry.location);
    
    // Show or hide no-data message
    const noMapData = document.getElementById('no-map-data');
    if (entriesWithLocation.length === 0) {
        noMapData.classList.remove('d-none');
        document.getElementById('map-container').classList.add('d-none');
        return;
    }
    
    noMapData.classList.add('d-none');
    document.getElementById('map-container').classList.remove('d-none');
    
    // Add markers for each entry
    entriesWithLocation.forEach(entry => {
        addLocationToMap(entry.results, entry.location, entry);
    });
    
    // Adjust map bounds to show all markers
    if (markers.length > 0) {
        const group = new L.featureGroup(markers);
        mainMap.fitBounds(group.getBounds(), {
            padding: [50, 50]
        });
    }
}

function clearMarkers() {
    // Remove all markers from the map
    markers.forEach(marker => {
        mainMap.removeLayer(marker);
    });
    markers = [];
}

function addLocationToMap(diagnosis, location, historyEntry = null) {
    if (!mainMap || !location) return;
    
    // Determine severity based on diagnosis results
    let severity = 'low';
    let topDiagnosis = { label: 'Desconhecido', score: 0 };
    
    diagnosis.forEach(result => {
        if (result.score > topDiagnosis.score) {
            topDiagnosis = result;
        }
        
        if (result.label !== 'Sadio' && result.score > 85) {
            severity = 'high';
        } else if (result.label !== 'Sadio' && result.score > 70 && severity !== 'high') {
            severity = 'medium';
        }
    });
    
    // Set marker color based on severity
    let markerColor = '#28a745'; // Green for low severity
    if (severity === 'high') {
        markerColor = '#dc3545'; // Red for high severity
    } else if (severity === 'medium') {
        markerColor = '#ffc107'; // Yellow for medium severity
    }
    
    // Create icon HTML
    const iconHtml = `
        <div class="custom-marker">
            <div class="marker-pin" style="background-color: ${markerColor};">
                <i class="fas fa-leaf"></i>
            </div>
        </div>
    `;
    
    const customIcon = L.divIcon({
        className: 'custom-div-icon',
        html: iconHtml,
        iconSize: [30, 42],
        iconAnchor: [15, 42]
    });
    
    // Create marker and add to map
    const marker = L.marker([location.latitude, location.longitude], {
        icon: customIcon
    }).addTo(mainMap);
    
    // Format date nicely if we have a history entry
    let dateText = 'Data desconhecida';
    if (historyEntry && historyEntry.date) {
        dateText = formatDate(historyEntry.date);
    }
    
    // Create popup content
    let popupContent = `
        <div class="map-popup">
            <h6 class="mb-2">${topDiagnosis.label} <span class="badge bg-${severity === 'high' ? 'danger' : (severity === 'medium' ? 'warning' : 'success')}">${topDiagnosis.score}%</span></h6>
            <div class="small text-secondary mb-2">
                <i class="fas fa-calendar-alt me-1"></i> ${dateText}
            </div>
    `;
    
    // Add treatment info if available
    if (historyEntry && historyEntry.treatment) {
        let treatmentStatusClass = 'bg-secondary';
        if (historyEntry.treatment.status === 'Em tratamento') {
            treatmentStatusClass = 'bg-warning';
        } else if (historyEntry.treatment.status === 'Concluído') {
            treatmentStatusClass = 'bg-success';
        } else if (historyEntry.treatment.status === 'Não tratável') {
            treatmentStatusClass = 'bg-danger';
        }
        
        popupContent += `
            <div class="mb-2">
                <span class="badge ${treatmentStatusClass} me-1">${historyEntry.treatment.status}</span>
            </div>
        `;
    }
    
    // Add location coordinates
    popupContent += `
            <div class="small text-secondary">
                <i class="fas fa-map-marker-alt me-1"></i> ${location.latitude.toFixed(5)}, ${location.longitude.toFixed(5)}
            </div>
        </div>
    `;
    
    // Bind popup to marker
    marker.bindPopup(popupContent, {
        maxWidth: 300,
        className: 'map-popup-container'
    });
    
    // Store marker reference
    markers.push(marker);
    
    return marker;
}

function updateMapMarkers() {
    // Update map markers when the map tab is visible
    if (document.getElementById('map-tab').classList.contains('d-none')) return;
    
    loadMapMarkers();
}

function updateLocationMapPreview() {
    // This function will be called to update mini map on diagnosis result
    const diagnosisResult = document.getElementById('diagnosis-result');
    if (diagnosisResult.classList.contains('d-none') || !currentLocation) return;
    
    // Check if mini map container already exists
    let miniMapContainer = document.getElementById('location-preview-map');
    if (!miniMapContainer) {
        // Create mini map container
        miniMapContainer = document.createElement('div');
        miniMapContainer.id = 'location-preview-map';
        miniMapContainer.style.height = '150px';
        miniMapContainer.style.marginTop = '1rem';
        miniMapContainer.style.borderRadius = '0.5rem';
        miniMapContainer.style.border = '1px solid #ddd';
        
        // Add to result container
        const locationInfo = document.getElementById('location-info');
        if (locationInfo) {
            locationInfo.appendChild(miniMapContainer);
        }
    }
    
    // Initialize mini map
    setTimeout(() => {
        const miniMap = L.map('location-preview-map', {
            zoomControl: false,
            attributionControl: false
        }).setView([currentLocation.latitude, currentLocation.longitude], 13);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19
        }).addTo(miniMap);
        
        // Add marker
        L.circleMarker([currentLocation.latitude, currentLocation.longitude], {
            radius: 8,
            fillColor: '#198754',
            color: '#fff',
            weight: 1,
            opacity: 1,
            fillOpacity: 0.8
        }).addTo(miniMap);
        
        // Disable interactions for mini map
        miniMap.dragging.disable();
        miniMap.touchZoom.disable();
        miniMap.doubleClickZoom.disable();
        miniMap.scrollWheelZoom.disable();
        
        // Fix Leaflet display issue
        setTimeout(() => {
            miniMap.invalidateSize();
        }, 100);
    }, 100);
}